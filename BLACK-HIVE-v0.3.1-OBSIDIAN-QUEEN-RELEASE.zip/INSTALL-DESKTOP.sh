#!/usr/bin/env bash
set -euo pipefail
python3 - <<'PYINNER'
from pathlib import Path
import sys
root=Path.home()/'HONEYTRAP-BLACK-HIVE-v0.2.0-WORKSHOP'
menu=root/'HIVE_MENU.py'
if not menu.is_file(): sys.exit('[BLACK HIVE] Install the v0.2 workshop package first; nothing changed.')
apps=Path.home()/'.local/share/applications'
apps.mkdir(parents=True,exist_ok=True)
entry=apps/'honeytrap-black-hive.desktop'
if entry.exists(): sys.exit('[BLACK HIVE] Existing desktop launcher preserved.')
wrapper=root/'OPEN-HIVE.sh'
if not wrapper.exists():
    wrapper.write_text('#!/bin/sh\ncd "$HOME/HONEYTRAP-BLACK-HIVE-v0.2.0-WORKSHOP" || exit 1\nexec python3 HIVE_MENU.py\n')
    wrapper.chmod(0o755)
entry.write_text('[Desktop Entry]\nType=Application\nName=HONEYTRAP Black Hive\nComment=Local defensive honeypot command center\nExec='+str(wrapper)+'\nPath='+str(root)+'\nTerminal=true\nIcon=utilities-terminal\nCategories=Utility;Security;\n')
entry.chmod(0o755)
print('[BLACK HIVE] Application-menu launcher installed; original v0.1 launcher untouched.')
PYINNER
