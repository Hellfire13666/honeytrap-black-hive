# HONEYTRAP // BLACK HIVE v0.3.1 · LIVE WATCH WORKSHOP

Separate, unpublished local upgrade. Does not modify the installed v0.3.0 or v0.1.0.

## What is new

- Live private browser dashboard at `http://127.0.0.1:8767/` (refreshes every 2 seconds).
- Reads actual sanitized `LiveSignalReports/events.jsonl` events from Live Signal v0.3.0.
- Counts events, routes, hashed fingerprints, and displays the last 100 sanitized events.
- No outward network calls, remote scripts, credential collection, or internet-facing listener.
- A monitored event is not evidence of an attacker or unique identity.

## Install and run

Use the ZIP from this release, then inside the extracted folder: `bash INSTALL.sh`.

First terminal: `cd "$HOME/HONEYTRAP-BLACK-HIVE-v0.3.1-LIVE-WATCH-WORKSHOP" && python3 LIVE_SIGNAL.py serve`

Second terminal: `cd "$HOME/HONEYTRAP-BLACK-HIVE-v0.3.1-LIVE-WATCH-WORKSHOP" && python3 LIVE_WATCH.py`

Open `http://127.0.0.1:8767/` in browser. From the local demo at `http://127.0.0.1:8766/`, click a decoy; watch the dashboard update.

Uses only Python standard library. Do not expose port 8767 publicly. Existing reports stay in their respective directories.
